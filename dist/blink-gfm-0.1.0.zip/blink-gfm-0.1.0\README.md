# Blink Girlfriend Mode

A network communication library for Roblox games with additional security features.

## Version
0.1.0

## Installation

### Using Rokit
`	oml
[tools]
blink-gfm = "lun-lun-lun-lun/blink-gfm@0.1.0"
`

### Using Aftman
`	oml
[tools]
blink-gfm = "lun-lun-lun-lun/blink-gfm@0.1.0"
`

## Usage

`lua
local Blink = require("blink-gfm")

-- Your code here
`
